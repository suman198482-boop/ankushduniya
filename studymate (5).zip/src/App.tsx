/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  ArrowUpRight, 
  BookOpen, 
  Calendar, 
  Check, 
  Clock, 
  Download, 
  ExternalLink, 
  FileText, 
  GraduationCap, 
  Heart, 
  Home, 
  Layers, 
  Link as LinkIcon,
  Play, 
  PlayCircle, 
  Search, 
  Send, 
  Share2, 
  Sparkles, 
  Tv, 
  User, 
  Video, 
  X,
  Bell,
  AlertCircle
} from 'lucide-react';

interface BatchItem {
  id: number | string;
  title: string;
  category_id?: number;
  start_at?: string;
  end_at?: string;
  image_large?: string;
  image_thumb?: string;
}

interface ClassroomTopic {
  id: number;
  name: string;
  videos: number;
  notes: number;
}

interface VideoLecture {
  id: number;
  name: string;
  thumb?: string;
  published_at?: string;
  video_url?: string;
  hd_video_url?: string;
  pdfs?: { title: string; url: string }[];
}

interface LessonDetail {
  id: number;
  course_id?: number;
  name: string;
  teacher?: { id?: number; name: string };
  videos: VideoLecture[];
  notes?: { id?: number; title: string; url: string }[];
}

interface VideoOptionsData {
  hd_video_url?: string;
  video_url?: string;
  pdfs?: { title: string; url: string }[];
}

interface TodayClass {
  id?: number;
  name?: string;
  subject?: string;
  teacher?: string;
  time?: string;
  thumb?: string;
  video_url?: string;
  hd_video_url?: string;
}

interface ActiveVideoState {
  name: string;
  url: string;
  server1Url?: string;
  server2Url?: string;
  activeServer: 1 | 2;
  pdfUrl?: string;
}

export type ThemeColor = 'gold' | 'cyan' | 'emerald' | 'purple' | 'crimson';

interface ThemeInfo {
  id: ThemeColor;
  name: string;
  dotBg: string;
  headerGradient: string;
  headerBorder: string;
  brandText: string;
  btn3DClass: string;
  borderAccent: string;
  borderAccentLight: string;
  textAccent: string;
  textAccentLight: string;
  bgGlow1: string;
  bgGlow2: string;
  badgeBg: string;
  activeTabStyle: string;
}

const THEMES: Record<ThemeColor, ThemeInfo> = {
  gold: {
    id: 'gold',
    name: 'Classic Gold (KGS)',
    dotBg: '#f59e0b',
    headerGradient: 'from-[#141824]/95 via-[#10141e]/95 to-[#090d16]/95',
    headerBorder: 'border-amber-400/30',
    brandText: 'from-amber-200 via-amber-300 to-yellow-400',
    btn3DClass: 'btn-3d-gold',
    borderAccent: 'border-amber-400/60',
    borderAccentLight: 'border-amber-400/20',
    textAccent: 'text-amber-400',
    textAccentLight: 'text-amber-200/70',
    bgGlow1: '#f59e0b',
    bgGlow2: '#d97706',
    badgeBg: 'bg-amber-400/10',
    activeTabStyle: 'btn-3d-gold !text-black'
  },
  cyan: {
    id: 'cyan',
    name: 'Ocean Blue (Tech)',
    dotBg: '#0ea5e9',
    headerGradient: 'from-[#0b1726]/95 via-[#08121f]/95 to-[#050c16]/95',
    headerBorder: 'border-sky-400/30',
    brandText: 'from-sky-200 via-sky-300 to-cyan-400',
    btn3DClass: 'btn-3d-cyan',
    borderAccent: 'border-sky-400/60',
    borderAccentLight: 'border-sky-400/20',
    textAccent: 'text-sky-400',
    textAccentLight: 'text-sky-200/70',
    bgGlow1: '#0284c7',
    bgGlow2: '#0369a1',
    badgeBg: 'bg-sky-400/10',
    activeTabStyle: 'btn-3d-cyan !text-black'
  },
  emerald: {
    id: 'emerald',
    name: 'Soft Emerald (Green)',
    dotBg: '#10b981',
    headerGradient: 'from-[#0a1a14]/95 via-[#071510]/95 to-[#040e0b]/95',
    headerBorder: 'border-emerald-400/30',
    brandText: 'from-emerald-200 via-emerald-300 to-teal-400',
    btn3DClass: 'btn-3d-emerald',
    borderAccent: 'border-emerald-400/60',
    borderAccentLight: 'border-emerald-400/20',
    textAccent: 'text-emerald-400',
    textAccentLight: 'text-emerald-200/70',
    bgGlow1: '#059669',
    bgGlow2: '#047857',
    badgeBg: 'bg-emerald-400/10',
    activeTabStyle: 'btn-3d-emerald !text-black'
  },
  purple: {
    id: 'purple',
    name: 'Royal Indigo (Violet)',
    dotBg: '#a855f7',
    headerGradient: 'from-[#170e28]/95 via-[#120a20]/95 to-[#0a0514]/95',
    headerBorder: 'border-purple-400/30',
    brandText: 'from-purple-200 via-purple-300 to-indigo-300',
    btn3DClass: 'btn-3d-purple',
    borderAccent: 'border-purple-400/60',
    borderAccentLight: 'border-purple-400/20',
    textAccent: 'text-purple-300',
    textAccentLight: 'text-purple-200/70',
    bgGlow1: '#7e22ce',
    bgGlow2: '#6b21a8',
    badgeBg: 'bg-purple-400/10',
    activeTabStyle: 'btn-3d-purple !text-white'
  },
  crimson: {
    id: 'crimson',
    name: 'Warm Ruby (Red)',
    dotBg: '#f43f5e',
    headerGradient: 'from-[#200d14]/95 via-[#18090f]/95 to-[#0f0408]/95',
    headerBorder: 'border-rose-400/30',
    brandText: 'from-rose-200 via-rose-300 to-red-400',
    btn3DClass: 'btn-3d-crimson',
    borderAccent: 'border-rose-400/60',
    borderAccentLight: 'border-rose-400/20',
    textAccent: 'text-rose-400',
    textAccentLight: 'text-rose-200/70',
    bgGlow1: '#e11d48',
    bgGlow2: '#be123c',
    badgeBg: 'bg-rose-400/10',
    activeTabStyle: 'btn-3d-crimson !text-white'
  }
};

// Helper to extract clean Subject and Teacher Name
function parseSubjectAndTeacher(rawName: string): { subject: string; teacher: string } {
  if (!rawName) return { subject: 'General Class', teacher: 'Khan Sir Faculty' };
  const parts = rawName.split(/\s+by\s+/i);
  if (parts.length >= 2) {
    return {
      subject: parts[0].trim(),
      teacher: parts.slice(1).join(' by ').trim()
    };
  }
  return {
    subject: rawName.trim(),
    teacher: 'Senior KGS Faculty'
  };
}

// API Fetch Helper with fallback
async function fetchStudyMateApi<T>(endpoint: string): Promise<T | null> {
  try {
    const res = await fetch(endpoint, {
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    });
    if (res.ok) {
      return (await res.json()) as T;
    }
  } catch {
    // continue
  }

  try {
    const directUrl = endpoint.startsWith('http') 
      ? endpoint 
      : `https://www.study-mate.in${endpoint}`;
    const res = await fetch(directUrl, {
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    });
    if (res.ok) {
      return (await res.json()) as T;
    }
  } catch {
    // continue
  }

  return null;
}

interface TestSeriesItem {
  id: string;
  title: string;
  totalQuestions: number;
  durationMinutes: number;
  category: string;
  totalMarks: number;
  questions: {
    q: string;
    options: string[];
    answer: number;
  }[];
}

const TEST_SERIES_DATA: TestSeriesItem[] = [
  {
    id: 'test-gs-1',
    title: 'KGS General Studies Full Mock Test 1',
    totalQuestions: 5,
    durationMinutes: 10,
    category: 'GS Prelims',
    totalMarks: 10,
    questions: [
      {
        q: 'Which Article of the Indian Constitution deals with the Right to Equality?',
        options: ['Article 12', 'Article 14-18', 'Article 19', 'Article 21'],
        answer: 1
      },
      {
        q: 'Who was the Viceroy of India during the Partition of Bengal in 1905?',
        options: ['Lord Curzon', 'Lord Ripon', 'Lord Dalhousie', 'Lord Canning'],
        answer: 0
      },
      {
        q: 'What is the SI unit of electric resistance?',
        options: ['Volt', 'Ampere', 'Ohm', 'Watt'],
        answer: 2
      },
      {
        q: 'Which river is known as the "Sorrow of Bihar"?',
        options: ['Ganga', 'Kosi', 'Son', 'Gandak'],
        answer: 1
      },
      {
        q: 'Which layer of the atmosphere contains the Ozone layer?',
        options: ['Troposphere', 'Stratosphere', 'Mesosphere', 'Thermosphere'],
        answer: 1
      }
    ]
  },
  {
    id: 'test-bpsc-1',
    title: 'BPSC Prelims Special Mock Paper 2026',
    totalQuestions: 4,
    durationMinutes: 8,
    category: 'State PCS',
    totalMarks: 8,
    questions: [
      {
        q: 'Where was Lord Buddha enlightened?',
        options: ['Sarnath', 'Bodh Gaya', 'Kushinagar', 'Vaishali'],
        answer: 1
      },
      {
        q: 'Who led the Revolt of 1857 in Bihar?',
        options: ['Kunwar Singh', 'Nana Saheb', 'Tantia Tope', 'Maulvi Ahmadullah'],
        answer: 0
      },
      {
        q: 'Which district of Bihar has the highest literacy rate as per 2011 census?',
        options: ['Patna', 'Rohtas', 'Gaya', 'Nalanda'],
        answer: 1
      },
      {
        q: 'In which year was the state of Bihar separated from Bengal?',
        options: ['1905', '1912', '1936', '1947'],
        answer: 1
      }
    ]
  }
];

const NCERT_BOOKS = [
  { class: 'Class 6', subject: 'History', title: 'Our Pasts - I', pdfUrl: 'https://ncert.nic.in/textbook.php' },
  { class: 'Class 6', subject: 'Geography', title: 'The Earth Our Habitat', pdfUrl: 'https://ncert.nic.in/textbook.php' },
  { class: 'Class 7', subject: 'History', title: 'Our Pasts - II', pdfUrl: 'https://ncert.nic.in/textbook.php' },
  { class: 'Class 8', subject: 'Polity', title: 'Social and Political Life - III', pdfUrl: 'https://ncert.nic.in/textbook.php' },
  { class: 'Class 9', subject: 'Economics', title: 'Economics Class 9', pdfUrl: 'https://ncert.nic.in/textbook.php' },
  { class: 'Class 10', subject: 'Polity', title: 'Democratic Politics - II', pdfUrl: 'https://ncert.nic.in/textbook.php' },
  { class: 'Class 11', subject: 'History', title: 'Themes in World History', pdfUrl: 'https://ncert.nic.in/textbook.php' },
  { class: 'Class 12', subject: 'Polity', title: 'Contemporary World Politics', pdfUrl: 'https://ncert.nic.in/textbook.php' },
];

export default function App() {
  // Navigation states: 'home' | 'portal' | 'batch_detail'
  const [viewMode, setViewMode] = useState<'home' | 'portal' | 'batch_detail'>('home');
  const [portalTab, setPortalTab] = useState<'batches' | 'favs' | 'testseries' | 'ncert'>('batches');
  
  // Permanent 3D Gold Theme (Fixed and optimized for smooth performance on all phones)
  const activeTheme = THEMES.gold;

  // Telegram Popup Modal on initial website load (Set to false so website opens directly without popups/redirects)
  const [showTelegramModal, setShowTelegramModal] = useState(false);

  // Batches state
  const [batches, setBatches] = useState<BatchItem[]>([]);
  const [loadingBatches, setLoadingBatches] = useState(false);
  const [batchSearch, setBatchSearch] = useState('');
  
  // Selected Batch for Detail View
  const [selectedBatch, setSelectedBatch] = useState<BatchItem | null>(null);
  const [batchDetailTab, setBatchDetailTab] = useState<'classroom' | 'today' | 'notice' | 'timetable'>('classroom');

  // Classroom Topics state (Real topics ONLY for this batch)
  const [classroomTopics, setClassroomTopics] = useState<ClassroomTopic[]>([]);
  const [loadingTopics, setLoadingTopics] = useState(false);

  // Selected Topic / Lesson state (Real lectures ONLY for this topic)
  const [selectedTopic, setSelectedTopic] = useState<ClassroomTopic | null>(null);
  const [lessonDetail, setLessonDetail] = useState<LessonDetail | null>(null);
  const [loadingLesson, setLoadingLesson] = useState(false);

  // 3-Options Modal for selected class with loaded links
  const [selectedLectureForOptions, setSelectedLectureForOptions] = useState<VideoLecture | null>(null);
  const [currentVideoOptions, setCurrentVideoOptions] = useState<VideoOptionsData | null>(null);
  const [loadingVideoOptions, setLoadingVideoOptions] = useState(false);

  // Video Player Modal state
  const [activeVideo, setActiveVideo] = useState<ActiveVideoState | null>(null);

  // Today Classes state
  const [todayClasses, setTodayClasses] = useState<TodayClass[]>([]);
  const [loadingToday, setLoadingToday] = useState(false);

  // Favourites in localStorage
  const [favourites, setFavourites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('ankush_fav_batches');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Test series running state
  const [activeTest, setActiveTest] = useState<TestSeriesItem | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [testSubmitted, setTestSubmitted] = useState(false);
  const [testScore, setTestScore] = useState(0);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Toggle Favourite
  const toggleFav = (id: string | number) => {
    const strId = String(id);
    let updated: string[];
    if (favourites.includes(strId)) {
      updated = favourites.filter(f => f !== strId);
      showToast('Removed from favourites');
    } else {
      updated = [...favourites, strId];
      showToast('Saved to favourites ⭐');
    }
    setFavourites(updated);
    try {
      localStorage.setItem('ankush_fav_batches', JSON.stringify(updated));
    } catch {}
  };

  // Fetch batches on mount from New_Sunny.json
  useEffect(() => {
    async function fetchBatches() {
      setLoadingBatches(true);
      try {
        const res = await fetch('https://sunnyji7256.github.io/kgs_batch_list/New_Sunny.json');
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data) && data.length > 0) {
            setBatches(data);
            setLoadingBatches(false);
            return;
          }
        }
      } catch (err) {
        console.warn('Error fetching batches:', err);
      }
      setLoadingBatches(false);
    }
    fetchBatches();
  }, []);

  // When a batch is selected, fetch ONLY ITS OWN real classroom topics
  const handleOpenBatch = async (batch: BatchItem) => {
    setSelectedBatch(batch);
    setSelectedTopic(null);
    setLessonDetail(null);
    setSelectedLectureForOptions(null);
    setCurrentVideoOptions(null);
    setBatchDetailTab('classroom');
    setViewMode('batch_detail');

    setLoadingTopics(true);
    setClassroomTopics([]);

    const data = await fetchStudyMateApi<{ classroom?: ClassroomTopic[] }>(`/api/classroom/${batch.id}`);
    if (data && Array.isArray(data.classroom)) {
      setClassroomTopics(data.classroom);
    } else {
      setClassroomTopics([]);
    }
    setLoadingTopics(false);
  };

  // Fetch today's classes for this batch
  useEffect(() => {
    if (viewMode === 'batch_detail' && batchDetailTab === 'today' && selectedBatch) {
      setLoadingToday(true);
      setTodayClasses([]);
      fetchStudyMateApi<{ todayclasses?: TodayClass[] }>(`/api/today/${selectedBatch.id}`)
        .then(data => {
          if (data && Array.isArray(data.todayclasses)) {
            setTodayClasses(data.todayclasses);
          } else {
            setTodayClasses([]);
          }
        })
        .finally(() => setLoadingToday(false));
    }
  }, [viewMode, batchDetailTab, selectedBatch]);

  // When a specific topic is clicked, fetch its video lectures
  const handleOpenTopic = async (topic: ClassroomTopic) => {
    setSelectedTopic(topic);
    setSelectedLectureForOptions(null);
    setCurrentVideoOptions(null);
    setLoadingLesson(true);
    setLessonDetail(null);

    const data = await fetchStudyMateApi<LessonDetail>(`/api/lesson/${topic.id}`);
    if (data && Array.isArray(data.videos)) {
      setLessonDetail(data);
    } else {
      setLessonDetail({
        id: topic.id,
        name: topic.name,
        videos: []
      });
    }
    setLoadingLesson(false);
  };

  // Open 3-Options Modal for a video
  const openVideoOptionsModal = async (lecture: VideoLecture) => {
    setSelectedLectureForOptions(lecture);
    setLoadingVideoOptions(true);
    setCurrentVideoOptions(null);

    const data = await fetchStudyMateApi<VideoOptionsData>(`/api/video/${lecture.id}`);
    if (data) {
      setCurrentVideoOptions(data);
    } else {
      setCurrentVideoOptions({
        hd_video_url: lecture.hd_video_url || lecture.video_url,
        video_url: lecture.video_url || lecture.hd_video_url,
        pdfs: lecture.pdfs
      });
    }
    setLoadingVideoOptions(false);
  };

  // Play Class in HD Player (Watch Class 1 or Watch Class 2)
  const handleDirectWatchClass = async (e: React.MouseEvent, lecture: VideoLecture, serverNumber: 1 | 2 = 1) => {
    e.stopPropagation();

    let s1 = lecture.hd_video_url || lecture.video_url;
    let s2 = lecture.video_url || lecture.hd_video_url;
    let pdf = lecture.pdfs?.[0]?.url;

    if (!s1 && !s2 && lecture.id) {
      showToast(`Connecting to Watch Class ${serverNumber}...`);
      const data = await fetchStudyMateApi<VideoOptionsData>(`/api/video/${lecture.id}`);
      if (data) {
        lecture.hd_video_url = data.hd_video_url;
        lecture.video_url = data.video_url;
        if (data.pdfs) lecture.pdfs = data.pdfs;
        s1 = data.hd_video_url || data.video_url;
        s2 = data.video_url || data.hd_video_url;
        pdf = data.pdfs?.[0]?.url;
      }
    }

    const targetUrl = serverNumber === 1 ? (s1 || s2) : (s2 || s1);

    if (targetUrl) {
      setActiveVideo({
        name: lecture.name,
        url: targetUrl,
        server1Url: s1,
        server2Url: s2,
        activeServer: serverNumber,
        pdfUrl: pdf
      });
      showToast(`Playing on Watch Class ${serverNumber} 🎬`);
    } else {
      showToast(`Watch Class ${serverNumber} link not available for this lecture.`);
    }
  };

  const handleDirectWatch = (e: React.MouseEvent, lecture: VideoLecture) => {
    return handleDirectWatchClass(e, lecture, 1);
  };

  const handleDirectLink2 = (e: React.MouseEvent, lecture: VideoLecture) => {
    return handleDirectWatchClass(e, lecture, 2);
  };

  // Direct Action: View Notes PDF
  const handleDirectPdf = async (e: React.MouseEvent, lecture: VideoLecture) => {
    e.stopPropagation();
    if (lecture.pdfs && lecture.pdfs.length > 0) {
      window.open(lecture.pdfs[0].url, '_blank');
      showToast('Opening Lecture Notes PDF...');
      return;
    }

    showToast('Fetching class notes PDF...');
    const data = await fetchStudyMateApi<VideoOptionsData>(`/api/video/${lecture.id}`);
    if (data?.pdfs && data.pdfs.length > 0) {
      window.open(data.pdfs[0].url, '_blank');
      showToast('Opening Lecture Notes PDF...');
    } else {
      showToast('No PDF notes attached to this class.');
    }
  };

  const handleShare = () => {
    const currentUrl = window.location.href;
    if (navigator.share) {
      navigator.share({
        title: 'ANKUSHKIDUNIYA',
        text: 'Access KGS Study Portal, Live Batches, Subjects & Teachers: ' + currentUrl,
        url: currentUrl,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(currentUrl);
      showToast('Direct Portal link copied to clipboard!');
    }
  };

  const filteredBatches = batches.filter(b => 
    b.title.toLowerCase().includes(batchSearch.toLowerCase())
  );

  const favBatches = batches.filter(b => favourites.includes(String(b.id)));

  // Test series
  const handleAnswerSelect = (qIdx: number, optIdx: number) => {
    if (testSubmitted) return;
    setSelectedAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
  };

  const submitTest = () => {
    if (!activeTest) return;
    let score = 0;
    activeTest.questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.answer) {
        score += 2;
      }
    });
    setTestScore(score);
    setTestSubmitted(true);
    showToast(`Test completed! Your score: ${score}/${activeTest.totalMarks}`);
  };

  const resetTest = () => {
    setActiveTest(null);
    setSelectedAnswers({});
    setTestSubmitted(false);
    setTestScore(0);
  };

  return (
    <div className="min-h-screen text-white relative selection:bg-amber-400/30 selection:text-white pb-12 transition-colors duration-500">
      {/* Background dynamic radial glow */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
        <div 
          className="absolute -top-[10%] -left-[10%] w-[550px] h-[550px] rounded-full blur-[140px] opacity-25 transition-all duration-700"
          style={{ background: activeTheme.bgGlow1 }}
        />
        <div 
          className="absolute -bottom-[10%] -right-[10%] w-[550px] h-[550px] rounded-full blur-[140px] opacity-20 transition-all duration-700"
          style={{ background: activeTheme.bgGlow2 }}
        />
      </div>

      {/* =========================================================================
          SCREEN 1: HOME SCREEN
          ========================================================================= */}
      {viewMode === 'home' && (
        <div className="max-w-[1000px] mx-auto my-6 sm:my-10 px-4 sm:px-6">
          {/* Top Control Bar with 3D Color Theme Picker */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2 text-xs font-semibold text-white/90 tracking-wide">
              <span 
                className="inline-block w-2.5 h-2.5 rounded-full animate-pulse shadow-md"
                style={{ backgroundColor: activeTheme.dotBg }}
              />
              <span className={`font-black ${activeTheme.textAccent}`}>ANKUSHKIDUNIYA</span>
              <span className="text-white/30">•</span>
              <span className="text-white/60">Study Portal</span>
            </div>

            <div className="flex items-center gap-2">
              <a
                href="https://t.me/ankushkiduniya"
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs px-3.5 py-1.5 rounded-xl border border-cyan-400/40 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-200 transition-all flex items-center gap-1.5 cursor-pointer no-underline shadow-md"
                title="Join Telegram Channel @ankushkiduniya"
              >
                <Send className="w-3.5 h-3.5 text-[#229ED9]" />
                <span className="font-bold">Telegram</span>
                <ArrowUpRight className="w-3 h-3 text-cyan-400" />
              </a>

              <button
                onClick={handleShare}
                className="text-xs px-3 py-1.5 rounded-xl border border-white/15 bg-white/5 hover:bg-white/10 text-white/80 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
                title="Share portal"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share</span>
              </button>
            </div>
          </div>

          {/* 3D Header */}
          <header className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 mb-8 text-center sm:text-left">
            <div className="relative group">
              {/* 3D Sphere Avatar */}
              <div 
                className="w-[82px] h-[82px] rounded-full avatar-3d flex items-center justify-center font-black text-3xl text-black tracking-wider transition-transform duration-300 group-hover:scale-105"
              >
                <span>AK</span>
              </div>
              <div className="absolute inset-0 rounded-full ring-2 ring-white/30 animate-ping pointer-events-none" style={{ animationDuration: '3s' }} />
            </div>

            <div>
              <h1 
                className={`text-2xl sm:text-3xl md:text-4xl font-black tracking-tight bg-gradient-to-r ${activeTheme.brandText} bg-clip-text text-transparent`}
              >
                Welcome to ANKUSHKIDUNIYA
              </h1>
              <p className="text-xs sm:text-sm text-white/80 mt-1 font-medium">
                Direct access to Khan Global Studies classes, mock tests & batch resources
              </p>
            </div>
          </header>

          {/* SECTION 1: KGS (Khan Sir) with 3D Depth */}
          <section className={`relative mt-8 p-5 sm:p-6 rounded-3xl card-3d overflow-hidden`}>
            <div className="relative z-10">
              <h2 className={`text-xl sm:text-2xl font-black ${activeTheme.textAccent} mb-4 flex items-center justify-between`}>
                <span>🕺 KGS (Khan Sir) 🕺</span>
                <span className={`text-xs font-bold ${activeTheme.textAccent} badge-3d px-3 py-1 rounded-full`}>
                  Click to Open Inside App
                </span>
              </h2>

              <div className="space-y-4">
                {/* Website 1 (3D Card) */}
                <div 
                  onClick={() => {
                    setViewMode('portal');
                    setPortalTab('batches');
                  }}
                  className="card-3d block p-4 sm:p-5 rounded-2xl text-white cursor-pointer no-underline group transition-all"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <span className={`text-base sm:text-lg font-black tracking-wide text-white group-hover:${activeTheme.textAccent} transition-colors`}>
                        🌐 Website 1 🌐
                      </span>
                      <span className={`text-[11px] badge-3d ${activeTheme.textAccent} px-2.5 py-0.5 rounded-lg font-mono font-bold`}>
                        Direct Portal
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs ${activeTheme.textAccentLight} font-bold hidden sm:inline`}>
                        Open Portal
                      </span>
                      <span className={`p-2 rounded-xl ${activeTheme.btn3DClass}`}>
                        <ArrowUpRight className="w-4 h-4" />
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-white/70 mt-1.5 pl-1 font-medium">
                    Live Khan Global Studies Batches, Subjects, Teachers & Lectures
                  </p>
                </div>

                {/* Website 2 (3D Card) */}
                <div 
                  onClick={() => {
                    setViewMode('portal');
                    setPortalTab('batches');
                  }}
                  className="card-3d block p-4 sm:p-5 rounded-2xl text-white cursor-pointer no-underline group transition-all"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <span className="text-base sm:text-lg font-black tracking-wide text-white group-hover:text-purple-300 transition-colors">
                        🚀 Website 2 🚀
                      </span>
                      <span className="text-[11px] badge-3d text-purple-300 px-2.5 py-0.5 rounded-lg font-mono font-bold">
                        High Speed Mirror
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-purple-300 font-bold hidden sm:inline">
                        Open Portal
                      </span>
                      <span className="p-2 rounded-xl btn-3d-purple">
                        <ArrowUpRight className="w-4 h-4 text-white" />
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-white/70 mt-1.5 pl-1 font-medium">
                    Direct access to courses, study schedule & online test papers
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* SECTION 2: KGS Test with 3D Depth */}
          <section className="relative mt-8 p-5 sm:p-6 rounded-3xl card-3d overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-xl sm:text-2xl font-black text-purple-300 mb-4 flex items-center justify-between">
                <span>🕺 KGS Test 🕺</span>
                <span className="text-xs font-bold text-purple-300 badge-3d px-3 py-1 rounded-full">
                  Mock & Test Series
                </span>
              </h2>

              <div className="space-y-3">
                <div 
                  onClick={() => {
                    setViewMode('portal');
                    setPortalTab('testseries');
                  }}
                  className="card-3d block p-4 sm:p-5 rounded-2xl text-white cursor-pointer no-underline group transition-all"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <span className="text-base sm:text-lg font-black tracking-wide text-white group-hover:text-emerald-300 transition-colors">
                        📝 KGS Test 📝
                      </span>
                      <span className="text-[11px] badge-3d text-emerald-300 px-2.5 py-0.5 rounded-lg font-mono font-bold">
                        Online Practice
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-emerald-300 font-bold hidden sm:inline">
                        Start Test
                      </span>
                      <span className="p-2 rounded-xl btn-3d-emerald">
                        <ArrowUpRight className="w-4 h-4 text-black" />
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-white/70 mt-1.5 pl-1 font-medium">
                    Solve live mock tests, GS quiz, answer analysis & practice sets
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Footer */}
          <footer className="mt-12 text-center text-xs text-white/50 pb-8 border-t border-white/10 pt-6">
            <p className="font-semibold text-white/70">© {new Date().getFullYear()} ANKUSHKIDUNIYA • Educational Portal</p>
            <p className="mt-1 text-emerald-400 font-medium text-[11px]">
              ⚡ Fast Direct Access • No Intermediate Redirects
            </p>
            <p className="mt-1 text-white/30 text-[10px]">Select any batch to open classroom & lectures directly</p>
          </footer>
        </div>
      )}

      {/* =========================================================================
          SCREEN 2: KHAN GLOBAL STUDIES PORTAL (3D Look)
          ========================================================================= */}
      {viewMode === 'portal' && (
        <div className="min-h-screen bg-[#060812] text-white">
          {/* Top Sticky Header with 3D Border & Drop Shadow */}
          <header className={`sticky top-0 z-40 bg-gradient-to-r ${activeTheme.headerGradient} backdrop-blur-md border-b-2 ${activeTheme.headerBorder} shadow-[0_10px_30px_rgba(0,0,0,0.8)] px-4 sm:px-6 py-3.5 flex items-center justify-between transition-colors duration-500`}>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setViewMode('home')}
                className={`px-3.5 py-1.5 rounded-xl border border-white/20 bg-white/10 hover:bg-white/20 font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-all cursor-pointer shadow-md active:translate-y-0.5`}
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Home</span>
              </button>

              <div className="flex items-center gap-2 pl-2 border-l border-white/20">
                <div className="w-9 h-9 rounded-full avatar-3d flex items-center justify-center font-black text-black text-sm">
                  AK
                </div>
                <div>
                  <h2 className={`text-sm sm:text-base font-black tracking-wide bg-gradient-to-r ${activeTheme.brandText} bg-clip-text text-transparent`}>
                    ANKUSHKIDUNIYA X Khan Global Studies
                  </h2>
                  <p className={`text-[10px] ${activeTheme.textAccentLight} hidden sm:block font-semibold`}>
                    Live Portal & Batches
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <a
                href="https://t.me/ankushkiduniya"
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-1.5 rounded-xl bg-[#229ED9] hover:bg-[#1e8bc2] text-white text-xs font-bold flex items-center gap-1.5 shadow-[0_4px_0_#146a94,0_8px_16px_rgba(34,158,217,0.5)] active:translate-y-0.5 transition-all cursor-pointer no-underline"
                title="Join Telegram Channel @ankushkiduniya"
              >
                <Send className="w-3.5 h-3.5 fill-white" />
                <span className="hidden sm:inline">Join Telegram</span>
                <ArrowUpRight className="w-3 h-3" />
              </a>
            </div>
          </header>

          {/* Animated RGB Marquee */}
          <div className="w-full bg-[#080d24] py-2 border-b border-white/10 overflow-hidden relative shadow-inner">
            <div className="rgb-marquee-text font-black text-xs sm:text-sm tracking-widest uppercase">
              ⚡ Welcome to ANKUSHKIDUNIYA X Khan Global Studies • Learn, Grow, Succeed • Live Batches, Notes & Online Test Series • Access Classroom & Lectures ⚡
            </div>
          </div>

          {/* Portal Main Content */}
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-6 sm:py-8">
            
            {/* Quick Feature Navigation Grid with 3D Depth */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-8">
              <button
                onClick={() => setPortalTab('batches')}
                className={`p-4 rounded-2xl text-center transition-all cursor-pointer card-3d ${
                  portalTab === 'batches'
                    ? activeTheme.activeTabStyle
                    : `text-white`
                }`}
              >
                <div 
                  className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-2 badge-3d"
                >
                  <GraduationCap className={`w-6 h-6 ${activeTheme.textAccent}`} />
                </div>
                <h3 className="font-black text-sm sm:text-base">KGS Batches</h3>
                <span className="text-[11px] opacity-70 block mt-0.5 font-semibold">{batches.length} Live Courses</span>
              </button>

              <button
                onClick={() => setPortalTab('favs')}
                className={`p-4 rounded-2xl text-center transition-all cursor-pointer card-3d ${
                  portalTab === 'favs'
                    ? 'btn-3d-crimson !text-white'
                    : 'text-white'
                }`}
              >
                <div className="w-12 h-12 mx-auto rounded-full badge-3d flex items-center justify-center mb-2">
                  <Heart className="w-6 h-6 text-rose-400 fill-rose-400" />
                </div>
                <h3 className="font-black text-sm sm:text-base">My Favourites</h3>
                <span className="text-[11px] opacity-70 block mt-0.5 font-semibold">{favourites.length} Saved</span>
              </button>

              <button
                onClick={() => setPortalTab('testseries')}
                className={`p-4 rounded-2xl text-center transition-all cursor-pointer card-3d ${
                  portalTab === 'testseries'
                    ? 'btn-3d-purple !text-white'
                    : 'text-white'
                }`}
              >
                <div className="w-12 h-12 mx-auto rounded-full badge-3d flex items-center justify-center mb-2">
                  <FileText className="w-6 h-6 text-purple-300" />
                </div>
                <h3 className="font-black text-sm sm:text-base">Test Series</h3>
                <span className="text-[11px] opacity-70 block mt-0.5 font-semibold">{TEST_SERIES_DATA.length} Practice Tests</span>
              </button>

              <button
                onClick={() => setPortalTab('ncert')}
                className={`p-4 rounded-2xl text-center transition-all cursor-pointer card-3d ${
                  portalTab === 'ncert'
                    ? 'btn-3d-emerald !text-black'
                    : 'text-white'
                }`}
              >
                <div className="w-12 h-12 mx-auto rounded-full badge-3d flex items-center justify-center mb-2">
                  <BookOpen className="w-6 h-6 text-emerald-300" />
                </div>
                <h3 className="font-black text-sm sm:text-base">NCERT Books</h3>
                <span className="text-[11px] opacity-70 block mt-0.5 font-semibold">Class 6-12 PDF</span>
              </button>
            </div>

            {/* TAB 1: KGS BATCHES LIST (3D Cards) */}
            {portalTab === 'batches' && (
              <div>
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
                  <div>
                    <h2 className={`text-xl sm:text-2xl font-black ${activeTheme.textAccent} flex items-center gap-2`}>
                      <GraduationCap className="w-6 h-6" />
                      <span>Khan Global Studies Batches</span>
                    </h2>
                    <p className="text-xs sm:text-sm text-white/70">
                      Click any batch to view its exact real subjects, faculty & lectures
                    </p>
                  </div>

                  {/* Search Bar */}
                  <div className="w-full sm:w-72 relative">
                    <Search className={`w-4 h-4 ${activeTheme.textAccent} absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none opacity-80`} />
                    <input
                      type="text"
                      value={batchSearch}
                      onChange={(e) => setBatchSearch(e.target.value)}
                      placeholder="Search batch name..."
                      className={`w-full pl-9 pr-4 py-2.5 text-xs sm:text-sm bg-black/50 border border-white/20 rounded-xl text-white placeholder-white/40 focus:outline-none focus:${activeTheme.borderAccent} shadow-inner`}
                    />
                    {batchSearch && (
                      <button 
                        onClick={() => setBatchSearch('')}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-white/50 hover:text-white"
                      >
                        Clear
                      </button>
                    )}
                  </div>
                </div>

                {loadingBatches ? (
                  <div className={`p-12 text-center ${activeTheme.textAccent}`}>
                    <div 
                      className="w-10 h-10 mx-auto border-4 border-t-transparent rounded-full animate-spin mb-3"
                      style={{ borderColor: activeTheme.dotBg, borderTopColor: 'transparent' }}
                    />
                    <p className="font-bold">Loading live KGS Batches...</p>
                  </div>
                ) : filteredBatches.length === 0 ? (
                  <div className="p-12 text-center text-white/50 card-3d rounded-2xl">
                    <AlertCircle className="w-10 h-10 text-white/30 mx-auto mb-2" />
                    <p>No batches match your search "{batchSearch}".</p>
                    <button 
                      onClick={() => setBatchSearch('')}
                      className={`mt-3 text-xs ${activeTheme.textAccent} underline cursor-pointer`}
                    >
                      Clear search
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredBatches.map((b) => {
                      const isFaved = favourites.includes(String(b.id));
                      return (
                        <div
                          key={b.id}
                          onClick={() => handleOpenBatch(b)}
                          className="card-3d rounded-3xl overflow-hidden flex flex-col justify-between cursor-pointer group"
                        >
                          <div>
                            {/* Batch Thumbnail with 3D Bevel */}
                            <div className="relative aspect-video bg-black/60 overflow-hidden border-b border-white/10">
                              <img
                                src={b.image_large || b.image_thumb || 'https://kgs-v2.akamaized.net/kgs/kgs/courses/large/c112b4b0-c967-4e6f-a638-fe31167dc852.png'}
                                alt={b.title}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = 'https://kgs-v2.akamaized.net/kgs/kgs/courses/large/c112b4b0-c967-4e6f-a638-fe31167dc852.png';
                                }}
                              />
                              <div className="absolute top-2.5 right-2.5">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    toggleFav(b.id);
                                  }}
                                  className="p-2 rounded-full bg-black/70 hover:bg-black/90 backdrop-blur-md transition-colors cursor-pointer border border-white/20 shadow-md"
                                  title={isFaved ? 'Remove from favorites' : 'Add to favorites'}
                                >
                                  <Heart className={`w-4 h-4 ${isFaved ? 'text-rose-500 fill-rose-500' : 'text-white'}`} />
                                </button>
                              </div>
                              <div 
                                className="absolute bottom-2 left-2 px-2.5 py-0.5 rounded-lg badge-3d text-[11px] font-mono font-bold"
                                style={{ color: activeTheme.dotBg }}
                              >
                                Batch #{b.id}
                              </div>
                            </div>

                            {/* Batch Details */}
                            <div className="p-5">
                              <h3 className={`font-black text-base text-white group-hover:${activeTheme.textAccent} transition-colors line-clamp-2 mb-2`}>
                                {b.title}
                              </h3>

                              <div className="space-y-1.5 text-xs text-white/70 mb-4">
                                <div className="flex items-center gap-1.5 font-medium">
                                  <Calendar className={`w-3.5 h-3.5 ${activeTheme.textAccent}`} />
                                  <span>Start: {b.start_at || 'Recently Started'}</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* 3D Action Button */}
                          <div className="p-5 pt-0">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenBatch(b);
                              }}
                              className={`w-full py-3 px-4 rounded-xl ${activeTheme.btn3DClass} flex items-center justify-center gap-2 cursor-pointer`}
                            >
                              <Play className="w-4 h-4 fill-current" />
                              <span className="font-extrabold text-sm">Open Batch Classroom</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: MY FAVOURITES */}
            {portalTab === 'favs' && (
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-rose-300 mb-2 flex items-center gap-2">
                  <Heart className="w-6 h-6 text-rose-500 fill-rose-500" />
                  <span>My Saved Courses & Batches</span>
                </h2>
                <p className="text-xs sm:text-sm text-white/60 mb-6">
                  Quick access to all batches you have bookmarked
                </p>

                {favBatches.length === 0 ? (
                  <div className="p-12 text-center text-white/50 card-3d rounded-2xl">
                    <Heart className="w-12 h-12 text-rose-400/40 mx-auto mb-3" />
                    <p className="text-base font-bold text-white/80">No favourite batches saved yet</p>
                    <button
                      onClick={() => setPortalTab('batches')}
                      className={`mt-4 px-5 py-2.5 rounded-xl ${activeTheme.btn3DClass} font-bold text-xs cursor-pointer`}
                    >
                      Browse Batches
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {favBatches.map((b) => (
                      <div
                        key={b.id}
                        onClick={() => handleOpenBatch(b)}
                        className="card-3d rounded-3xl overflow-hidden p-5 flex flex-col justify-between cursor-pointer group"
                      >
                        <div>
                          <img
                            src={b.image_large || b.image_thumb || 'https://kgs-v2.akamaized.net/kgs/kgs/courses/large/c112b4b0-c967-4e6f-a638-fe31167dc852.png'}
                            alt={b.title}
                            className="w-full aspect-video object-cover rounded-2xl mb-3 border border-white/10"
                          />
                          <h3 className={`font-black text-base text-white mb-2 group-hover:${activeTheme.textAccent}`}>
                            {b.title}
                          </h3>
                        </div>

                        <div className="flex items-center gap-2 pt-3">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenBatch(b);
                            }}
                            className={`flex-1 py-2.5 rounded-xl ${activeTheme.btn3DClass} font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer`}
                          >
                            <Play className="w-3.5 h-3.5 fill-current" />
                            <span>Open Classroom</span>
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleFav(b.id);
                            }}
                            className="p-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 cursor-pointer shadow-md"
                            title="Remove"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: TEST SERIES */}
            {portalTab === 'testseries' && (
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-purple-300 mb-2 flex items-center gap-2">
                  <FileText className="w-6 h-6 text-purple-400" />
                  <span>KGS Online Test Series & Mocks</span>
                </h2>
                <p className="text-xs sm:text-sm text-white/60 mb-6">
                  Practice with high-yield questions, timed mock tests, and instant scorecards
                </p>

                {!activeTest ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {TEST_SERIES_DATA.map((t) => (
                      <div
                        key={t.id}
                        className="card-3d rounded-3xl p-6 flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-[11px] font-black badge-3d text-purple-300 px-3 py-1 rounded-full">
                              {t.category}
                            </span>
                            <span className="text-xs text-white/70 flex items-center gap-1 font-semibold">
                              <Clock className="w-3.5 h-3.5 text-purple-300" />
                              <span>{t.durationMinutes} Mins</span>
                            </span>
                          </div>

                          <h3 className="font-black text-base text-white mb-2">
                            {t.title}
                          </h3>

                          <div className="flex items-center gap-4 text-xs text-white/60 mb-5 font-medium">
                            <span>Questions: {t.totalQuestions}</span>
                            <span>Total Marks: {t.totalMarks}</span>
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            setActiveTest(t);
                            setSelectedAnswers({});
                            setTestSubmitted(false);
                            setTestScore(0);
                          }}
                          className="w-full py-3 rounded-xl btn-3d-purple text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <Play className="w-4 h-4 fill-white" />
                          <span>Start Test Now</span>
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="max-w-2xl mx-auto card-3d rounded-3xl p-6 sm:p-8">
                    <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
                      <div>
                        <span className="text-xs text-purple-300 font-mono font-bold uppercase">{activeTest.category}</span>
                        <h3 className="text-lg sm:text-xl font-black text-white">{activeTest.title}</h3>
                      </div>
                      <button
                        onClick={resetTest}
                        className="text-xs px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer"
                      >
                        Exit Test
                      </button>
                    </div>

                    <div className="space-y-6">
                      {activeTest.questions.map((q, qIdx) => (
                        <div key={qIdx} className="p-5 rounded-2xl bg-black/40 border border-white/10 shadow-inner">
                          <p className="font-bold text-sm sm:text-base text-white mb-4">
                            <span className={`mr-2 font-black ${activeTheme.textAccent}`}>Q{qIdx + 1}.</span>
                            {q.q}
                          </p>

                          <div className="space-y-2.5">
                            {q.options.map((opt, optIdx) => {
                              const isSelected = selectedAnswers[qIdx] === optIdx;
                              const isCorrect = q.answer === optIdx;
                              let btnStyle = 'bg-white/[0.05] border-white/15 text-white/80 hover:bg-white/10';
                              
                              if (testSubmitted) {
                                if (isCorrect) {
                                  btnStyle = 'bg-emerald-500/20 border-emerald-400 text-emerald-300 font-bold';
                                } else if (isSelected && !isCorrect) {
                                  btnStyle = 'bg-rose-500/20 border-rose-400 text-rose-300';
                                }
                              } else if (isSelected) {
                                btnStyle = 'bg-purple-500/30 border-purple-400 text-purple-200 font-bold shadow-[0_0_15px_rgba(168,85,247,0.4)]';
                              }

                              return (
                                <button
                                  key={optIdx}
                                  onClick={() => handleAnswerSelect(qIdx, optIdx)}
                                  className={`w-full text-left p-3.5 rounded-xl border text-xs sm:text-sm flex items-center justify-between transition-all cursor-pointer ${btnStyle}`}
                                >
                                  <span>{opt}</span>
                                  {testSubmitted && isCorrect && (
                                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                                  )}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-8 pt-4 border-t border-white/10 flex items-center justify-between">
                      {testSubmitted ? (
                        <div className="flex items-center gap-3">
                          <div className="px-5 py-2.5 rounded-xl badge-3d text-emerald-300 font-black text-sm">
                            Score: {testScore} / {activeTest.totalMarks}
                          </div>
                          <button
                            onClick={resetTest}
                            className="px-5 py-2.5 rounded-xl btn-3d-purple text-white font-bold text-xs cursor-pointer"
                          >
                            Back to Test Series
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between w-full">
                          <span className="text-xs text-white/60 font-semibold">
                            Answered {Object.keys(selectedAnswers).length} of {activeTest.totalQuestions}
                          </span>
                          <button
                            onClick={submitTest}
                            className="px-6 py-3 rounded-xl btn-3d-emerald text-black font-black text-xs sm:text-sm cursor-pointer"
                          >
                            Submit Test
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: NCERT BOOKS */}
            {portalTab === 'ncert' && (
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-emerald-300 mb-2 flex items-center gap-2">
                  <BookOpen className="w-6 h-6 text-emerald-400" />
                  <span>NCERT Textbooks (Class 6 - 12)</span>
                </h2>
                <p className="text-xs sm:text-sm text-white/60 mb-6">
                  Official NCERT syllabus books essential for UPSC, BPSC, SSC & State PCS exams
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {NCERT_BOOKS.map((b, idx) => (
                    <div
                      key={idx}
                      className="card-3d rounded-2xl p-5 flex flex-col justify-between group"
                    >
                      <div>
                        <span className="text-[10px] font-black uppercase tracking-wider badge-3d text-emerald-300 px-2.5 py-1 rounded-md">
                          {b.class}
                        </span>
                        <h3 className="font-bold text-sm text-white mt-3 mb-1 group-hover:text-emerald-200">
                          {b.title}
                        </h3>
                        <p className="text-xs text-white/50">{b.subject}</p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-white/10">
                        <a
                          href={b.pdfUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full py-2.5 px-3 rounded-xl btn-3d-emerald text-black text-xs font-black flex items-center justify-center gap-1.5 no-underline"
                        >
                          <BookOpen className="w-3.5 h-3.5" />
                          <span>View NCERT Book</span>
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 3: BATCH DETAIL & CLASSROOM VIEW (3D Depth)
          ========================================================================= */}
      {viewMode === 'batch_detail' && selectedBatch && (
        <div className="min-h-screen bg-[#060812] text-white">
          {/* Top Sticky Header with 3D Border & Drop Shadow */}
          <header className={`sticky top-0 z-40 bg-gradient-to-r ${activeTheme.headerGradient} backdrop-blur-md border-b-2 ${activeTheme.headerBorder} shadow-[0_10px_30px_rgba(0,0,0,0.8)] px-4 sm:px-6 py-3.5 flex items-center justify-between transition-colors duration-500`}>
            <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
              {/* Back Button */}
              <button
                onClick={() => {
                  if (selectedTopic) {
                    setSelectedTopic(null);
                    setLessonDetail(null);
                    setSelectedLectureForOptions(null);
                    setCurrentVideoOptions(null);
                  } else {
                    setViewMode('portal');
                    setPortalTab('batches');
                  }
                }}
                className={`px-3.5 sm:px-4 py-2 rounded-xl ${activeTheme.btn3DClass} font-black text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer shrink-0`}
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{selectedTopic ? 'Back to Subjects' : 'Back to Batches'}</span>
              </button>

              {/* Direct Jump to All Batches */}
              {selectedTopic && (
                <button
                  onClick={() => {
                    setSelectedTopic(null);
                    setLessonDetail(null);
                    setSelectedLectureForOptions(null);
                    setCurrentVideoOptions(null);
                    setViewMode('portal');
                    setPortalTab('batches');
                  }}
                  className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer shrink-0 shadow-sm"
                  title="Switch to another batch"
                >
                  <Layers className={`w-3.5 h-3.5 ${activeTheme.textAccent}`} />
                  <span className="hidden sm:inline">All Batches</span>
                </button>
              )}

              {/* Title / Breadcrumb */}
              <div className="pl-2 border-l border-white/20 truncate">
                <h2 className={`text-xs sm:text-sm md:text-base font-black tracking-wide bg-gradient-to-r ${activeTheme.brandText} bg-clip-text text-transparent text-3d-emboss truncate`}>
                  {selectedTopic ? `${selectedTopic.name}` : selectedBatch.title}
                </h2>
                <div className="flex items-center gap-1 text-[10px] text-white/60 truncate font-semibold">
                  <span>Batches</span>
                  <span>/</span>
                  <span className="truncate">{selectedBatch.title}</span>
                  {selectedTopic && (
                    <>
                      <span>/</span>
                      <span className={`font-black truncate ${activeTheme.textAccent}`}>{selectedTopic.name}</span>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 pl-2">
              <a
                href="https://t.me/ankushkiduniya"
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-xl bg-[#229ED9] hover:bg-[#1e8bc2] text-white text-xs font-bold flex items-center gap-1.5 shadow-[0_4px_0_#146a94] active:translate-y-0.5 transition-all cursor-pointer no-underline"
                title="Join Telegram Channel @ankushkiduniya"
              >
                <Send className="w-3 h-3 fill-white" />
                <span className="hidden md:inline">Telegram</span>
              </a>

              <button
                onClick={() => setViewMode('home')}
                className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 text-xs flex items-center gap-1 cursor-pointer"
                title="Return to Main Home"
              >
                <Home className="w-3.5 h-3.5 text-cyan-300" />
                <span className="hidden sm:inline">Home</span>
              </button>
            </div>
          </header>

          {/* Navigation Tabs (Class Room, Today's Class, Notice, Timetable) with 3D Tactile Buttons */}
          {!selectedTopic && (
            <div className="max-w-[700px] mx-auto my-5 px-4">
              <nav className="flex items-center justify-center gap-2 p-2 rounded-2xl card-3d overflow-x-auto">
                <button
                  onClick={() => setBatchDetailTab('classroom')}
                  className={`flex-1 min-w-[100px] py-2.5 px-3 rounded-xl flex flex-col items-center gap-1 transition-all cursor-pointer text-xs font-black ${
                    batchDetailTab === 'classroom'
                      ? activeTheme.activeTabStyle
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  <GraduationCap className="w-5 h-5" />
                  <span>Class Room</span>
                </button>

                <button
                  onClick={() => setBatchDetailTab('today')}
                  className={`flex-1 min-w-[100px] py-2.5 px-3 rounded-xl flex flex-col items-center gap-1 transition-all cursor-pointer text-xs font-black ${
                    batchDetailTab === 'today'
                      ? activeTheme.activeTabStyle
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>Today's Class</span>
                </button>

                <button
                  onClick={() => setBatchDetailTab('notice')}
                  className={`flex-1 min-w-[100px] py-2.5 px-3 rounded-xl flex flex-col items-center gap-1 transition-all cursor-pointer text-xs font-black ${
                    batchDetailTab === 'notice'
                      ? activeTheme.activeTabStyle
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  <Bell className="w-5 h-5" />
                  <span>Notice</span>
                </button>

                <button
                  onClick={() => setBatchDetailTab('timetable')}
                  className={`flex-1 min-w-[100px] py-2.5 px-3 rounded-xl flex flex-col items-center gap-1 transition-all cursor-pointer text-xs font-black ${
                    batchDetailTab === 'timetable'
                      ? activeTheme.activeTabStyle
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  <Calendar className="w-5 h-5" />
                  <span>Timetable</span>
                </button>
              </nav>
            </div>
          )}

          {/* Main Content Area */}
          <main className="max-w-[1100px] mx-auto px-4 sm:px-6 py-4">

            {/* SUB-VIEW A: CLASS ROOM SUBJECTS & TEACHERS LIST */}
            {!selectedTopic && batchDetailTab === 'classroom' && (
              <div>
                <div className="mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                      <GraduationCap className={`w-5 h-5 ${activeTheme.textAccent}`} />
                      <span>{selectedBatch.title}</span>
                    </h3>
                    <p className={`text-xs ${activeTheme.textAccentLight} font-semibold`}>
                      {classroomTopics.length > 0
                        ? `Is batch me kul ${classroomTopics.length} subjects uplabdh hain:`
                        : 'Checking subjects for this batch...'}
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      setViewMode('portal');
                      setPortalTab('batches');
                    }}
                    className="px-4 py-2 rounded-xl card-3d text-xs font-bold flex items-center gap-1.5 cursor-pointer text-white/90 hover:text-white"
                  >
                    <Layers className={`w-3.5 h-3.5 ${activeTheme.textAccent}`} />
                    <span>Explore Other Batches</span>
                  </button>
                </div>

                {loadingTopics ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3].map(n => (
                      <div key={n} className="p-6 rounded-3xl card-3d animate-pulse h-44">
                        <div className="h-5 bg-white/20 rounded w-3/4 mb-4" />
                        <div className="h-4 bg-white/10 rounded w-1/2 mb-6" />
                        <div className="flex gap-4">
                          <div className="h-8 bg-white/10 rounded-xl w-24" />
                          <div className="h-8 bg-white/10 rounded-xl w-24" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : classroomTopics.length === 0 ? (
                  <div className="p-12 text-center text-white/50 card-3d rounded-3xl">
                    <GraduationCap className={`w-14 h-14 mx-auto mb-3 opacity-60 ${activeTheme.textAccent}`} />
                    <p className="text-base font-black text-white/80">No classes uploaded for this batch yet</p>
                    <p className="text-xs text-white/60 mt-1 max-w-sm mx-auto font-medium">
                      Is batch ke lecture videos aur notes jald hi KGS team dwara upload kiye jayenge. Kripya dusra batch check karein.
                    </p>
                    <button
                      onClick={() => {
                        setViewMode('portal');
                        setPortalTab('batches');
                      }}
                      className={`mt-5 px-6 py-2.5 rounded-xl ${activeTheme.btn3DClass} font-bold text-xs cursor-pointer`}
                    >
                      ← Back to Other Batches
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {classroomTopics.map((topic) => {
                      const { subject, teacher } = parseSubjectAndTeacher(topic.name);
                      return (
                        <div
                          key={topic.id}
                          onClick={() => handleOpenTopic(topic)}
                          className="p-6 rounded-3xl card-3d cursor-pointer group flex flex-col justify-between relative overflow-hidden"
                        >
                          <div className="relative z-10">
                            <h4 className={`text-base sm:text-lg font-black text-white group-hover:${activeTheme.textAccent} transition-colors mb-2`}>
                              {subject}
                            </h4>

                            <div className="flex items-center gap-2 mb-4 text-xs font-bold text-cyan-300 badge-3d px-3 py-1.5 rounded-xl w-fit">
                              <User className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                              <span>Faculty: {teacher}</span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between gap-2 pt-4 border-t border-white/10 relative z-10">
                            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-lg badge-3d ${activeTheme.textAccent} text-xs font-bold`}>
                              <Video className="w-3.5 h-3.5" />
                              <span>{topic.videos} Videos</span>
                            </div>

                            <div className="flex items-center gap-1.5 px-3 py-1 rounded-lg badge-3d text-purple-300 text-xs font-bold">
                              <FileText className="w-3.5 h-3.5 text-purple-400" />
                              <span>{topic.notes} Notes</span>
                            </div>

                            <span className={`p-2 rounded-xl ${activeTheme.btn3DClass}`}>
                              <ArrowUpRight className="w-4 h-4" />
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* SUB-VIEW B: SPECIFIC TOPIC LECTURES LIST (3D Action Buttons) */}
            {selectedTopic && (
              <div>
                {/* Back & Breadcrumb Navigation Bar */}
                <div className="flex items-center justify-between gap-3 mb-5 p-3.5 rounded-2xl card-3d">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setSelectedTopic(null);
                        setLessonDetail(null);
                        setSelectedLectureForOptions(null);
                        setCurrentVideoOptions(null);
                      }}
                      className={`px-4 py-2 rounded-xl ${activeTheme.btn3DClass} font-black text-xs flex items-center gap-1.5 cursor-pointer`}
                    >
                      <ArrowLeft className="w-4 h-4" />
                      <span>Back to Subjects</span>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedTopic(null);
                        setLessonDetail(null);
                        setSelectedLectureForOptions(null);
                        setCurrentVideoOptions(null);
                        setViewMode('portal');
                        setPortalTab('batches');
                      }}
                      className="px-3 py-2 rounded-xl card-3d text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Layers className={`w-3.5 h-3.5 ${activeTheme.textAccent}`} />
                      <span>All Batches</span>
                    </button>
                  </div>

                  <span className="text-xs text-white/60 hidden sm:inline font-semibold">
                    Click any class to see the 3 options
                  </span>
                </div>

                {/* Subject Header Card */}
                <div className="p-6 rounded-3xl card-3d mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <span className={`text-xs font-mono uppercase ${activeTheme.textAccent} font-black tracking-wider badge-3d px-3 py-1 rounded-full`}>
                      Subject Lectures & Materials
                    </span>
                    <h3 className="text-xl sm:text-2xl font-black text-white mt-2">
                      {selectedTopic.name}
                    </h3>
                    <div className="flex items-center gap-2 mt-2 text-xs text-cyan-300 font-semibold">
                      <User className="w-4 h-4 text-cyan-400" />
                      <span>
                        Teacher: {lessonDetail?.teacher?.name || parseSubjectAndTeacher(selectedTopic.name).teacher}
                      </span>
                    </div>
                  </div>

                  <div className={`px-4 py-2 rounded-xl badge-3d ${activeTheme.textAccent} text-xs font-black`}>
                    {lessonDetail?.videos.length || 0} Lectures Available
                  </div>
                </div>

                {loadingLesson ? (
                  <div className={`p-12 text-center ${activeTheme.textAccent}`}>
                    <div 
                      className="w-10 h-10 mx-auto border-4 border-t-transparent rounded-full animate-spin mb-3"
                      style={{ borderColor: activeTheme.dotBg, borderTopColor: 'transparent' }}
                    />
                    <p className="font-bold">Loading lectures & classes...</p>
                  </div>
                ) : (
                  /* Real Video Lectures List with 3D tactile buttons */
                  <div className="space-y-4">
                    {lessonDetail?.videos && lessonDetail.videos.length > 0 ? (
                      lessonDetail.videos.map((vid, idx) => (
                        <div
                          key={vid.id || idx}
                          onClick={() => openVideoOptionsModal(vid)}
                          className="p-5 rounded-3xl card-3d flex flex-col md:flex-row items-start md:items-center justify-between gap-4 cursor-pointer group"
                        >
                          <div className="flex items-start sm:items-center gap-4 flex-1 min-w-0">
                            {/* 3D Thumbnail */}
                            <div className="relative w-28 sm:w-36 aspect-video rounded-2xl overflow-hidden bg-black/60 shrink-0 border border-white/20 shadow-md">
                              <img
                                src={vid.thumb || selectedBatch.image_large || 'https://kgs-v2.akamaized.net/kgs/kgs/courses/large/c112b4b0-c967-4e6f-a638-fe31167dc852.png'}
                                alt={vid.name}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                              <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                                <Play className="w-7 h-7 text-white fill-white/80 filter drop-shadow-md" />
                              </div>
                            </div>

                            {/* Lecture Info */}
                            <div className="min-w-0">
                              <h5 className={`font-black text-sm sm:text-base text-white group-hover:${activeTheme.textAccent} transition-colors line-clamp-2`}>
                                {vid.name}
                              </h5>
                              <div className="flex flex-wrap items-center gap-3 text-xs text-white/60 mt-1.5 font-medium">
                                {vid.published_at && (
                                  <span className="flex items-center gap-1">
                                    <Calendar className={`w-3.5 h-3.5 ${activeTheme.textAccent}`} />
                                    <span>{new Date(vid.published_at).toLocaleDateString('en-GB')}</span>
                                  </span>
                                )}
                                <span className="text-cyan-300 font-bold">
                                  Faculty: {lessonDetail?.teacher?.name || parseSubjectAndTeacher(selectedTopic.name).teacher}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* 3 Real 3D Tactile Buttons on Card */}
                          <div 
                            className="flex flex-wrap items-center gap-2 w-full md:w-auto shrink-0 pt-3 md:pt-0 border-t md:border-t-0 border-white/10"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {/* Watch Class 1 */}
                            <button
                              onClick={(e) => handleDirectWatchClass(e, vid, 1)}
                              className={`flex-1 sm:flex-initial px-3.5 py-2.5 rounded-xl ${activeTheme.btn3DClass} flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap text-xs font-black`}
                              title="Watch Class 1 (Server 1 HD)"
                            >
                              <PlayCircle className="w-4 h-4 fill-current" />
                              <span>Watch Class 1</span>
                            </button>

                            {/* Watch Class 2 */}
                            <button
                              onClick={(e) => handleDirectWatchClass(e, vid, 2)}
                              className="flex-1 sm:flex-initial px-3.5 py-2.5 rounded-xl btn-3d-cyan !text-black flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap text-xs font-black"
                              title="Watch Class 2 (Server 2 Fast Mirror)"
                            >
                              <Tv className="w-4 h-4 text-black" />
                              <span>Watch Class 2</span>
                            </button>

                            {/* Notes PDF */}
                            <button
                              onClick={(e) => handleDirectPdf(e, vid)}
                              className="flex-1 sm:flex-initial px-3 py-2.5 rounded-xl btn-3d-purple flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap text-xs font-bold"
                              title="View & Download Lecture Notes PDF"
                            >
                              <FileText className="w-4 h-4 text-white" />
                              <span>Notes PDF</span>
                            </button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-8 text-center text-white/50 card-3d rounded-2xl">
                        <Video className="w-10 h-10 text-white/30 mx-auto mb-2" />
                        <p>No video lectures available for this subject yet.</p>
                      </div>
                    )}
                  </div>
                )}

                {/* Bottom Back Navigation Bar */}
                <div className="mt-8 pt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                  <button
                    onClick={() => {
                      setSelectedTopic(null);
                      setLessonDetail(null);
                      setSelectedLectureForOptions(null);
                      setCurrentVideoOptions(null);
                    }}
                    className={`px-5 py-3 rounded-xl ${activeTheme.btn3DClass} font-black text-xs sm:text-sm flex items-center gap-2 cursor-pointer`}
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back to Other Subjects</span>
                  </button>

                  <button
                    onClick={() => {
                      setSelectedTopic(null);
                      setLessonDetail(null);
                      setSelectedLectureForOptions(null);
                      setCurrentVideoOptions(null);
                      setViewMode('portal');
                      setPortalTab('batches');
                    }}
                    className="px-5 py-3 rounded-xl card-3d text-white font-bold text-xs sm:text-sm flex items-center gap-2 cursor-pointer"
                  >
                    <Layers className={`w-4 h-4 ${activeTheme.textAccent}`} />
                    <span>Check Another Batch</span>
                  </button>
                </div>
              </div>
            )}

            {/* SUB-VIEW C: TODAY'S CLASS */}
            {!selectedTopic && batchDetailTab === 'today' && (
              <div>
                <h3 className="text-lg sm:text-xl font-black text-emerald-300 mb-2 flex items-center gap-2">
                  <Play className="w-5 h-5 text-emerald-400 fill-emerald-400" />
                  <span>Today's Live & Scheduled Classes</span>
                </h3>
                <p className="text-xs text-white/60 mb-6">
                  {selectedBatch.title} ke liye aaj ki live stream classes aur timing
                </p>

                {loadingToday ? (
                  <div className="p-12 text-center text-emerald-300">
                    <div className="w-10 h-10 mx-auto border-4 border-emerald-400 border-t-transparent rounded-full animate-spin mb-3" />
                    <p className="font-bold">Checking today's schedule...</p>
                  </div>
                ) : todayClasses.length > 0 ? (
                  <div className="space-y-4">
                    {todayClasses.map((cls, idx) => (
                      <div
                        key={idx}
                        className="p-5 rounded-3xl card-3d flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                      >
                        <div className="flex items-start sm:items-center gap-4">
                          <div className="w-14 h-14 rounded-2xl badge-3d flex items-center justify-center shrink-0">
                            <Video className="w-7 h-7 text-emerald-400" />
                          </div>
                          <div>
                            <span className="text-[11px] font-black text-emerald-300 uppercase badge-3d px-2.5 py-0.5 rounded-md">
                              {cls.time || '10:00 AM Live'}
                            </span>
                            <h4 className="font-black text-base text-white mt-1.5">
                              {cls.name || `${selectedBatch.title} - Live Class`}
                            </h4>
                            <p className="text-xs text-white/70 mt-0.5 font-medium">
                              Faculty: {cls.teacher || 'Khan Sir Faculty Team'}
                            </p>
                          </div>
                        </div>

                        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                          <button
                            onClick={() => {
                              const s1 = cls.hd_video_url || cls.video_url;
                              const s2 = cls.video_url || cls.hd_video_url;
                              if (s1) {
                                setActiveVideo({
                                  name: cls.name || 'Today Live Class',
                                  url: s1,
                                  server1Url: s1,
                                  server2Url: s2,
                                  activeServer: 1
                                });
                                showToast('Playing: Watch Class 1 🎬');
                              } else {
                                showToast('Connecting to Watch Class 1 stream...');
                              }
                            }}
                            className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl btn-3d-gold text-black font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <PlayCircle className="w-4 h-4 fill-black" />
                            <span>Watch Class 1</span>
                          </button>

                          <button
                            onClick={() => {
                              const s1 = cls.hd_video_url || cls.video_url;
                              const s2 = cls.video_url || cls.hd_video_url;
                              const playUrl = s2 || s1;
                              if (playUrl) {
                                setActiveVideo({
                                  name: cls.name || 'Today Live Class',
                                  url: playUrl,
                                  server1Url: s1,
                                  server2Url: s2,
                                  activeServer: 2
                                });
                                showToast('Playing: Watch Class 2 🎬');
                              } else {
                                showToast('Connecting to Watch Class 2 stream...');
                              }
                            }}
                            className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl btn-3d-cyan text-black font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <Tv className="w-4 h-4 text-black" />
                            <span>Watch Class 2</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-12 text-center text-white/50 card-3d rounded-2xl">
                    <p className="text-base font-bold text-white/80">No classes scheduled for today in this batch</p>
                    <p className="text-xs text-white/50 mt-1">Check the timetable tab for the weekly lecture schedule.</p>
                  </div>
                )}
              </div>
            )}

            {/* SUB-VIEW D: NOTICE & UPDATES */}
            {!selectedTopic && batchDetailTab === 'notice' && (
              <div className="space-y-4">
                <h3 className="text-lg sm:text-xl font-black text-purple-300 mb-2 flex items-center gap-2">
                  <Bell className="w-5 h-5 text-purple-400" />
                  <span>Batch Announcements & Notices</span>
                </h3>

                <div className="p-6 rounded-3xl card-3d">
                  <div className="flex items-center justify-between text-xs text-purple-300 mb-2 font-bold">
                    <span className="uppercase badge-3d px-3 py-1 rounded-md">Official Notice • Batch #{selectedBatch.id}</span>
                    <span>Recent Update</span>
                  </div>
                  <h4 className="font-black text-base text-white mb-2">
                    Study Material & Chapter PDF Uploaded
                  </h4>
                  <p className="text-xs text-white/80 leading-relaxed font-medium">
                    Sabhi vidyarthiyo ko soochit kiya jata hai ki is batch ke naye class notes aur solved practice sheets Class Room section me uplabdh kar di gayi hain.
                  </p>
                </div>
              </div>
            )}

            {/* SUB-VIEW E: TIMETABLE */}
            {!selectedTopic && batchDetailTab === 'timetable' && (
              <div>
                <h3 className="text-lg sm:text-xl font-black text-cyan-300 mb-2 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-cyan-400" />
                  <span>Weekly Lecture Schedule</span>
                </h3>
                <p className="text-xs text-white/60 mb-6">
                  {selectedBatch.title} ka routine aur teacher timings
                </p>

                <div className="p-6 rounded-3xl card-3d">
                  <div className="space-y-3.5">
                    {classroomTopics.length > 0 ? (
                      classroomTopics.map((top, idx) => {
                        const { subject, teacher } = parseSubjectAndTeacher(top.name);
                        const times = [
                          '08:00 AM - 09:30 AM',
                          '10:00 AM - 11:30 AM',
                          '03:00 PM - 04:30 PM',
                          '05:00 PM - 06:30 PM'
                        ];
                        const slot = times[idx % times.length];
                        return (
                          <div key={idx} className="p-4 rounded-2xl bg-black/40 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-inner">
                            <div>
                              <span className={`text-sm font-black ${activeTheme.textAccent}`}>{subject}</span>
                              <p className="text-xs text-white/60 font-medium">Faculty: {teacher}</p>
                            </div>
                            <div className="text-xs font-black text-cyan-300 badge-3d px-3 py-1.5 rounded-xl w-fit">
                              Monday to Friday • {slot}
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <p className="text-xs text-white/60">Class timings will be updated soon for this batch.</p>
                    )}
                  </div>
                </div>
              </div>
            )}

          </main>
        </div>
      )}

      {/* =========================================================================
          MODAL: 3-OPTIONS POPUP (3D Tactile Buttons)
          ========================================================================= */}
      {selectedLectureForOptions && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div 
            className="relative w-full max-w-md card-3d !bg-[#0c101d] rounded-3xl p-6 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.9)] text-center overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Close (Kut) Button */}
            <button
              onClick={() => {
                setSelectedLectureForOptions(null);
                setCurrentVideoOptions(null);
              }}
              className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer border border-white/10 shadow-md"
              title="Close Dialog"
            >
              <X className="w-5 h-5 text-white" />
            </button>

            {/* Lecture 3D Icon */}
            <div 
              className="w-16 h-16 mx-auto rounded-3xl avatar-3d flex items-center justify-center mb-3.5"
            >
              <Play className="w-8 h-8 text-black fill-black" />
            </div>

            <span className={`text-[11px] font-mono uppercase tracking-wider ${activeTheme.textAccent} font-black badge-3d px-3.5 py-1 rounded-full`}>
              Class Options
            </span>

            <h3 className="text-base sm:text-lg font-black text-white mt-2.5 mb-1.5 line-clamp-2">
              {selectedLectureForOptions.name}
            </h3>
            
            {loadingVideoOptions ? (
              <p className={`text-xs ${activeTheme.textAccent} mb-5 flex items-center justify-center gap-1.5 animate-pulse font-bold`}>
                <span className="inline-block w-2.5 h-2.5 rounded-full bg-current animate-ping" />
                <span>Loading official 3D class links...</span>
              </p>
            ) : (
              <p className="text-xs text-white/70 mb-5 font-medium">
                Neeche diye gaye 3 options me se chunein:
              </p>
            )}

            {/* 3 Real 3D Tactile Buttons */}
            <div className="space-y-3 text-left">
              {/* Option 1: 3D Watch Class 1 */}
              <button
                onClick={() => {
                  const s1 = currentVideoOptions?.hd_video_url || currentVideoOptions?.video_url || selectedLectureForOptions.hd_video_url || selectedLectureForOptions.video_url;
                  const s2 = currentVideoOptions?.video_url || currentVideoOptions?.hd_video_url || selectedLectureForOptions.video_url || selectedLectureForOptions.hd_video_url;
                  if (s1) {
                    setActiveVideo({
                      name: selectedLectureForOptions.name,
                      url: s1,
                      server1Url: s1,
                      server2Url: s2,
                      activeServer: 1,
                      pdfUrl: currentVideoOptions?.pdfs?.[0]?.url || selectedLectureForOptions.pdfs?.[0]?.url
                    });
                    setSelectedLectureForOptions(null);
                    showToast('Playing on Watch Class 1 🎬');
                  } else {
                    showToast('Watch Class 1 link not available.');
                  }
                }}
                className={`w-full p-4 rounded-2xl ${activeTheme.btn3DClass} flex items-center justify-between cursor-pointer`}
              >
                <div className="flex items-center gap-3">
                  <PlayCircle className="w-6 h-6 fill-current shrink-0" />
                  <div>
                    <span className="text-sm font-black block">
                      1. Watch Class 1
                    </span>
                    <span className="text-[11px] opacity-80 font-bold">Server 1 • Main HD Stream</span>
                  </div>
                </div>
                <ArrowUpRight className="w-5 h-5 shrink-0" />
              </button>

              {/* Option 2: 3D Watch Class 2 */}
              <button
                onClick={() => {
                  const s1 = currentVideoOptions?.hd_video_url || currentVideoOptions?.video_url || selectedLectureForOptions.hd_video_url || selectedLectureForOptions.video_url;
                  const s2 = currentVideoOptions?.video_url || currentVideoOptions?.hd_video_url || selectedLectureForOptions.video_url || selectedLectureForOptions.hd_video_url;
                  const playUrl = s2 || s1;
                  if (playUrl) {
                    setActiveVideo({
                      name: selectedLectureForOptions.name,
                      url: playUrl,
                      server1Url: s1,
                      server2Url: s2,
                      activeServer: 2,
                      pdfUrl: currentVideoOptions?.pdfs?.[0]?.url || selectedLectureForOptions.pdfs?.[0]?.url
                    });
                    setSelectedLectureForOptions(null);
                    showToast('Playing on Watch Class 2 🎬');
                  } else {
                    showToast('Watch Class 2 link not available.');
                  }
                }}
                className="w-full p-4 rounded-2xl btn-3d-cyan !text-black flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <Tv className="w-6 h-6 text-black shrink-0" />
                  <div>
                    <span className="text-sm font-black text-black block">
                      2. Watch Class 2
                    </span>
                    <span className="text-[11px] text-black/80 font-bold flex items-center gap-1">
                      <LinkIcon className="w-3 h-3 text-black" />
                      <span>Server 2 • Fast Alternative Mirror</span>
                    </span>
                  </div>
                </div>
                <ArrowUpRight className="w-5 h-5 text-black shrink-0" />
              </button>

              {/* Option 3: 3D View Notes PDF */}
              <button
                onClick={() => {
                  const pdfUrl = currentVideoOptions?.pdfs?.[0]?.url || selectedLectureForOptions.pdfs?.[0]?.url;
                  if (pdfUrl) {
                    window.open(pdfUrl, '_blank');
                    showToast('Opening Notes PDF...');
                    setSelectedLectureForOptions(null);
                  } else {
                    showToast('No PDF notes attached to this class.');
                  }
                }}
                className="w-full p-4 rounded-2xl btn-3d-purple flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <FileText className="w-6 h-6 text-white shrink-0" />
                  <div>
                    <span className="text-sm font-black text-white block">
                      3. View Notes PDF
                    </span>
                    <span className="text-[11px] text-white/80 font-bold">
                      {currentVideoOptions?.pdfs?.[0]?.title ? 'Official handwritten PDF notes' : 'Lecture PDF document'}
                    </span>
                  </div>
                </div>
                <Download className="w-5 h-5 text-white shrink-0" />
              </button>
            </div>

            {/* Close Button */}
            <button
              onClick={() => {
                setSelectedLectureForOptions(null);
                setCurrentVideoOptions(null);
              }}
              className="mt-5 w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/60 hover:text-white text-xs font-bold transition-colors cursor-pointer border border-white/10"
            >
              Cancel / Close
            </button>
          </div>
        </div>
      )}

      {/* =========================================================================
          VIDEO PLAYER MODAL (3D Frame)
          ========================================================================= */}
      {activeVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
          <div 
            className="relative w-full max-w-4xl card-3d !bg-[#0b0f19] rounded-3xl overflow-hidden shadow-[0_25px_60px_rgba(0,0,0,0.9)] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="bg-[#101524] px-5 py-3.5 flex items-center justify-between border-b border-white/10">
              <div className="flex items-center gap-2 min-w-0">
                <button
                  onClick={() => setActiveVideo(null)}
                  className={`px-3.5 py-1.5 rounded-xl ${activeTheme.btn3DClass} font-black text-xs flex items-center gap-1 cursor-pointer shrink-0`}
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
                <h4 className="font-black text-xs sm:text-sm text-white truncate ml-2">
                  {activeVideo.name}
                </h4>
              </div>
              <button
                onClick={() => setActiveVideo(null)}
                className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Dual Server Control Bar: Watch Class 1 & Watch Class 2 */}
            <div className="bg-[#0e1424] px-4 sm:px-5 py-2.5 flex flex-wrap items-center justify-between gap-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold text-white/60 uppercase tracking-wider hidden sm:inline">Active Stream:</span>
                <button
                  onClick={() => {
                    const target = activeVideo.server1Url || activeVideo.url;
                    setActiveVideo({ ...activeVideo, url: target, activeServer: 1 });
                    showToast('Switched to Watch Class 1 ⚡');
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                    activeVideo.activeServer === 1
                      ? 'btn-3d-gold !text-black shadow-md ring-2 ring-amber-300'
                      : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                >
                  <PlayCircle className="w-3.5 h-3.5 fill-current" />
                  <span>Watch Class 1</span>
                </button>

                <button
                  onClick={() => {
                    const target = activeVideo.server2Url || activeVideo.server1Url || activeVideo.url;
                    setActiveVideo({ ...activeVideo, url: target, activeServer: 2 });
                    showToast('Switched to Watch Class 2 🚀');
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                    activeVideo.activeServer === 2
                      ? 'btn-3d-cyan !text-black shadow-md ring-2 ring-cyan-300'
                      : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                >
                  <Tv className="w-3.5 h-3.5" />
                  <span>Watch Class 2</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={activeVideo.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white text-xs font-bold flex items-center gap-1 cursor-pointer no-underline"
                  title="Open video in new tab / external player"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">New Tab</span>
                </a>
              </div>
            </div>

            {/* Video Frame */}
            <div className="relative aspect-video w-full bg-black">
              {activeVideo.url ? (
                <iframe
                  src={activeVideo.url}
                  title={activeVideo.name}
                  className="w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center">
                  <Play className={`w-16 h-16 ${activeTheme.textAccent} mb-3 animate-pulse`} />
                  <p className="font-black text-base text-white">{activeVideo.name}</p>
                </div>
              )}
            </div>

            {/* Video Footer info */}
            <div className="p-4 bg-[#101524] flex items-center justify-between border-t border-white/10">
              <span className="text-xs text-white/60 font-semibold">Khan Global Studies Stream Player</span>
              {activeVideo.pdfUrl && (
                <a
                  href={activeVideo.pdfUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-xl btn-3d-purple text-white text-xs font-black no-underline flex items-center gap-1.5"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>View Class Notes PDF</span>
                </a>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          POPUP MODAL: TELEGRAM CHANNEL JOIN (3D Feel)
          ========================================================================= */}
      {showTelegramModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div 
            className="relative w-full max-w-sm sm:max-w-md card-3d !bg-[#090d16] rounded-3xl p-7 shadow-[0_25px_60px_rgba(0,0,0,0.9)] text-center overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Close (Kut) Button */}
            <button
              onClick={() => setShowTelegramModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-colors cursor-pointer border border-white/10 shadow-md"
              title="Close (Band karein)"
              aria-label="Close Telegram dialog"
            >
              <X className="w-5 h-5 text-white" />
            </button>

            {/* Glowing 3D Telegram Icon */}
            <div className="mx-auto w-18 h-18 rounded-3xl avatar-3d !bg-gradient-to-tr !from-[#229ED9] !to-cyan-400 flex items-center justify-center shadow-[0_12px_28px_rgba(34,158,217,0.7)] mb-4">
              <svg viewBox="0 0 24 24" className="w-10 h-10 fill-white">
                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.121l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.46c.537-.194 1.006.131.832.926z" />
              </svg>
            </div>

            {/* Modal Heading */}
            <h3 className="text-xl font-black text-white mb-2 flex items-center justify-center gap-1.5">
              <span>Join Telegram Channel</span>
              <Sparkles className="w-5 h-5 text-cyan-300" />
            </h3>

            <p className="text-sm text-cyan-100/90 mb-6 leading-relaxed font-medium">
              Sabhi latest study materials, test updates, PDF notes aur live class links paane ke liye hamara official Telegram channel join karein!
            </p>

            {/* Action Buttons */}
            <div className="space-y-3">
              <a
                href="https://t.me/ankushkiduniya"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setShowTelegramModal(false)}
                className="w-full py-3.5 px-4 rounded-2xl font-black text-white btn-3d-cyan !text-black shadow-lg flex items-center justify-center gap-2 cursor-pointer no-underline text-base"
              >
                <Send className="w-4 h-4 fill-black" />
                <span>Join Channel Now (@ankushkiduniya)</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>

              <button
                onClick={() => setShowTelegramModal(false)}
                className="w-full py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold text-white/60 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer border border-white/10"
              >
                Baad me dekhenge (Close)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating 3D Telegram Button */}
      <a
        href="https://t.me/ankushkiduniya"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-5 left-5 z-40 p-3.5 rounded-2xl btn-3d-cyan !text-black shadow-2xl flex items-center gap-2 cursor-pointer no-underline"
        title="Join Official Telegram Channel @ankushkiduniya"
      >
        <Send className="w-5 h-5 fill-black" />
        <span className="text-xs font-black pr-1 hidden sm:inline">Join Telegram (@ankushkiduniya)</span>
      </a>

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 card-3d !bg-[#0e1626]/95 border border-white/20 text-white px-5 py-3 rounded-2xl shadow-2xl backdrop-blur-lg flex items-center gap-2 text-xs sm:text-sm animate-bounce font-bold">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
