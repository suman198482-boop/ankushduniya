import express from 'express';
import type { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  // In development, AI Studio passes '--port 3000'. In Cloud Run production, it runs 'node server.ts' and sets PORT=8080.
  const isDev = process.argv.includes('--port') || process.env.NODE_ENV === 'development';
  const PORT = isDev ? 3000 : parseInt(process.env.PORT || '8080', 10);
  const distPath = path.resolve(__dirname, 'dist');

  // CORS headers
  app.use((_req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');
    next();
  });

  // API Proxy Handler for Study-Mate
  app.use('/api', async (req: Request, res: Response) => {
    try {
      const targetUrl = `https://www.study-mate.in/api${req.url}`;
      const response = await fetch(targetUrl, {
        method: req.method,
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });

      res.status(response.status);
      response.headers.forEach((value, key) => {
        // Skip hop-by-hop headers
        if (!['content-encoding', 'transfer-encoding', 'connection'].includes(key.toLowerCase())) {
          res.setHeader(key, value);
        }
      });

      const data = await response.arrayBuffer();
      res.send(Buffer.from(data));
    } catch (err: any) {
      console.error('API Proxy error:', err?.message || err);
      res.status(502).json({ error: 'Proxy error connecting to Study-Mate' });
    }
  });

  if (isDev) {
    // Development mode: attach Vite dev server
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // Production mode: serve static built assets
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT} [mode: ${isDev ? 'dev' : 'prod'}]`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
